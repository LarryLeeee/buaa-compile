import frontend.Lexer.Lexer;
import frontend.Lexer.Token;
import frontend.Parser.Parser;
import frontend.Visitor;
import ir.Value.Module;

import java.io.File;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.ArrayList;

public class Compiler {

    public static void main(String[] args) {
        Lexer lexer = new Lexer();
        try {
            File file1 = new File("testfile.txt");
            if (file1.isFile() && file1.exists()) {
                InputStreamReader read = new InputStreamReader(
                        new FileInputStream(file1));
                BufferedReader bufferedReader = new BufferedReader(read);
                String lineTxt = null;
                while ((lineTxt = bufferedReader.readLine()) != null) {
                    lexer.setInput(lineTxt);
                }
                read.close();
            } else {
                System.out.println("File not found!");
            }
            File file2 = new File("llvm_ir.txt");
            FileWriter fileWriter = new FileWriter(file2);
            ArrayList<Token> tokens = lexer.getTokens();
            Parser parser = new Parser(tokens);
            parser.parseCompUnit();
            Visitor visitor = new Visitor(parser.getCompUnit());
            visitor.visitCompUnit();
            Module module = visitor.getModule();
            ArrayList<String> outputs = new ArrayList<>();
            module.getOutputs(outputs);
            for (String string : outputs) {
                fileWriter.write(string + "\n");
            }
            fileWriter.close();
        } catch (Exception e) {
            System.out.println("Error!");
            e.printStackTrace();
        }
    }
}
