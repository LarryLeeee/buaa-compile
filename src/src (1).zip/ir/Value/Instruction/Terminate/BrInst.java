package ir.Value.Instruction.Terminate;

import ir.Value.BasicBlock;
import ir.Value.Instruction.TAG;
import ir.Value.Value;

import java.util.ArrayList;

public class BrInst extends TerminateInst {

    public String judge;

    public BrInst(Value cond, BasicBlock trueBlock, BasicBlock falseBlock, BasicBlock parent) {
        super(null, parent, 3, TAG.br);
        addOperand(cond);
        addOperand(trueBlock);
        addOperand(falseBlock);
        if (cond == null) {
            numOp = 1;
        }
    }

    public void getOutputs(ArrayList<String> outputs) {
        StringBuilder sb = new StringBuilder();
        sb.append("\t").append("br ");
        if (numOp == 1) {
            sb.append(operands.get(1).type.string()).append(" ").append(operands.get(1).name);
        } else {
            sb.append("i1 ").append(operands.get(0).name).append(",").append(" ")
                    .append(operands.get(1).type.string()).append(" ").append(operands.get(1).name).append(",").append(" ")
                    .append(operands.get(2).type.string()).append(" ").append(operands.get(2).name);
        }
        outputs.add(sb.toString());
    }

}
