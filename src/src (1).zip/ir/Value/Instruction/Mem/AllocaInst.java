package ir.Value.Instruction.Mem;

import ir.Type.PointerType;
import ir.Type.Type;
import ir.Value.BasicBlock;
import ir.Value.Instruction.TAG;

import java.util.ArrayList;

public class AllocaInst extends MemInst {

    //这里name既是指令的名字，也代表着变量名
    public AllocaInst(String name, Type type, BasicBlock parent) {
        super(new PointerType(type), parent, 1, TAG.alloca);
        this.name = name;
    }

    public void getOutputs(ArrayList<String> outputs) {
        outputs.add("\t" + name + " = alloca " + ((PointerType) (type)).pointType.string());
    }
}
