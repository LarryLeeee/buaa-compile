package ir.Value.Instruction.Mem;

import ir.Type.ArrayType;
import ir.Type.PointerType;
import ir.Type.Type;
import ir.Value.BasicBlock;
import ir.Value.Instruction.TAG;
import ir.Value.Value;

import java.util.ArrayList;

public class GepInst extends MemInst {

    public ArrayList<Value> indexes;//第一个是pointerType，后面的是index;此外，根本不需要Type，因为type是pointerType指向的类型

    public GepInst(String name, Type type, BasicBlock parent, ArrayList<Value> indexes) {
        super(type, parent, indexes.size(), TAG.gep);
        this.name = name;
        this.indexes = indexes;
    }

    @Override
    public void getOutputs(ArrayList<String> outputs) {
        StringBuilder sb = new StringBuilder();
        sb.append("\t").append(name).append("= getelementptr ")
                .append(((PointerType) (indexes.get(0).type)).pointType.string());
        for (Value value : indexes) {
            sb.append(", ").append(value.type.string()).append(" ").append(value.name);
        }
        outputs.add(sb.toString());
    }
}
