package frontend.Lexer;

public interface Token {

    public String getType();

    public String getName();
}


