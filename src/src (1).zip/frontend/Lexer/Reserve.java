package frontend.Lexer;
//ReservedWord
public class Reserve implements Token{

    public int line;
    private String name;

    public Reserve(String name,int line){
        this.name=name;
        this.line=line;
    }

    @Override
    public String getType() {
        return name;
    }

    public String getName() {
        return name;
    }
}
