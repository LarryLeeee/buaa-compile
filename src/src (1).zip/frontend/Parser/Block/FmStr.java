package frontend.Parser.Block;

public class FmStr {

    public FmStr(){

    }


}
