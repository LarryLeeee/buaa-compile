package frontend.Parser;

public class Btype {

    private String type;

    public Btype() {

    }

    public void setType(String type) {
        this.type = type;
    }
}
