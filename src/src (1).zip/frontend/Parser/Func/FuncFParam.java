package frontend.Parser.Func;

import frontend.Lexer.Id;
import frontend.Parser.Decl.ConstExp;

public class FuncFParam {
    public Id id;
    public ConstExp constExp;
    public String type;

    public FuncFParam() {
        id = null;
        type = "Ident";
        constExp = null;
    }

    public void addId(Id id) {
        this.id = id;
    }

    public void addConstExp(ConstExp constExp) {
        this.constExp = constExp;
        type="twoDimArr";
    }
}
