package frontend.Parser.Func;

public class FuncType {

    public String type;

    public FuncType() {
        type = "int";
    }

    public void setType(String type) {
        this.type = type;
    }
}
