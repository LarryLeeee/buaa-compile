package frontend.Parser.Decl;

import frontend.Lexer.Id;

import java.util.ArrayList;

public class ConstDef {
    public Id id;
    public ArrayList<ConstExp> constExps;
    public ConstInitval constInitval;

    public ConstDef() {
        constExps = new ArrayList<>();
        constInitval = null;
    }

    public void addId(Id id) {
        this.id = id;
    }

    public void addConstExp(ConstExp constExp) {
        constExps.add(constExp);
    }

    public void addConstInitval(ConstInitval constInitval) {
        this.constInitval = constInitval;
    }

    public Id getId() {
        return id;
    }

}
