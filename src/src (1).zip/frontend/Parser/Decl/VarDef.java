package frontend.Parser.Decl;

import frontend.Lexer.Id;

import java.util.ArrayList;

public class VarDef {
    public Id id;
    public ArrayList<ConstExp> constExps;
    public InitVal initVal;

    public VarDef() {
        id = null;
        constExps = new ArrayList<>();
        initVal = null;
    }

    public void addId(Id id) {
        this.id = id;
    }

    public void addConstExp(ConstExp constExp) {
        constExps.add(constExp);
    }

    public void addInitVal(InitVal initVal) {
        this.initVal = initVal;
    }
}
