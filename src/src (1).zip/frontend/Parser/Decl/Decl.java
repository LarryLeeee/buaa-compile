package frontend.Parser.Decl;

public class Decl {
    private String type;

    public Decl() {

    }

    public void setType(String type) {
        this.type = type;
    }

    public void addVarDecl(VarDecl varDecl) {

    }

    public void addConstDecl(ConstDecl constDecl) {

    }

}
