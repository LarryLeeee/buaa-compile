package frontend.Parser.Exp;

public class UnaryOp {

    public String type;

    public UnaryOp() {
        type = null;
    }

    public void setType(String type) {
        this.type = type;
    }
}
